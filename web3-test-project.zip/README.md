# Getting Started with Web3 Connect Wallet

Built with Create React App + Typescript + Web3 + Chakra-UI

## Instruction

```
git clone https://github.com/televerse03/web3-test-project.git
cd web3-test-project
npm install
npm run start
```
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
